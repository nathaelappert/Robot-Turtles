package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Color;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;

public class Test {

    private final JPanel plateau = new JPanel(new BorderLayout(3, 3));
    private JButton[][] Case = new JButton[8][8];
    //JToolBar tool = new JToolBar();
    //Insets Margin = new Insets(0, 0, 0, 0);
    int taille = 8;


    Test() {
        initializeGui();

    }

    public final void initializeGui() {
        //plateau.setBorder(new EmptyBorder(5, 5, 5, 200));
        //tool.setFloatable(false);
        //plateau.add(tool, BorderLayout.PAGE_START);
        JPanel c1Board = new JPanel(new GridLayout(8, 8));
        c1Board.setBorder(new LineBorder(Color.BLACK));
        plateau.add(c1Board);

        for (int i = 0; i < Case.length; i++) {
            for (int j = 0; j < Case[i].length; j++) {
                JButton b = new JButton();
                //b.setMargin(Margin);
                b.setOpaque(false);
                b.setContentAreaFilled(false);
                //b.setFocusPainted(false);
                //b.setBorderPainted(false);
                //Color c=new Color(1f,0f,0f,.5f );
                //c1Board.setBackground(c);
                Case[j][i] = b;
            }
        }


        for (int i = 0; i < taille; i++) {
            for (int j = 0; j < taille; j++) {
                c1Board.add(Case[j][i]);
                Case[7][i].setIcon(new ImageIcon(new ImageIcon("/Users/Felix/IdeaProjects/RobotTurtle2/imagesTurtle/Wall2.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT)));
                //Case[7][i].add(new JLabel(new ImageIcon("/Users/Felix/IdeaProjects/imagesTurtle/WoodBox.png")));
            }
        }


        //plateau.add(new JLabel(new ImageIcon("/Users/Felix/IdeaProjects/imagesTurtle/Franklin.jpg")));

    }


    public static void main(String[] args) {
        Test gb = new Test();
        JFrame frame = new JFrame("Robot Turtle");
        frame.add(gb.plateau);
        frame.setLocationByPlatform(true);
        frame.setMinimumSize(frame.getSize());
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(700,700));
        frame.setMinimumSize(new Dimension(700,700));
        frame.setLocation(50,50);
        frame.pack();
        frame.setVisible(true);
        //frame.paintComponents(gb);

    }
    public void paintComponent(Graphics g){
        try{
            Image img = ImageIO.read(new File("/Users/Felix/IdeaProjects/imagesTurtle/background.jpeg"));
            g.drawImage(img, 0,0, 700,700, (ImageObserver) this);
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public static Image scaleImage(Image source, int width, int height) {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = (Graphics2D) img.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(source, 0, 0, width, height, null);
        g.dispose();
        return img;
    }

}