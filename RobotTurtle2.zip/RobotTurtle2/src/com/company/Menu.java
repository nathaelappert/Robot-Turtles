package com.company;


import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Menu extends JFrame {

    public Menu() {
        JPanel pan = new JPanel();
        //pan.setLayout(null);
        JButton bouton = new JButton("Cliquez pour jouer !");
        bouton.setBounds(320,500,200,29);
        pan.add(bouton);
        this.setTitle("Robot Turtles");
        this.setSize(640, 600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pan.setBackground(Color.WHITE);
        //pan.add(bouton);
        //pan.add(bouton, BorderLayout.SOUTH);
        //pan.setBounds(400, 600, 200, 100);
        this.setContentPane(new Panneau("/Users/Felix/IdeaProjects/RobotTurtle2/imagesTurtle/Menu.jpg"));
        setSize(900, 600);
        add(pan);
        this.setVisible(true);
        bouton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                //System.out.println("Ici !");
                //Menu menu = new Menu();
                /*
                JPanel mp = new JPanel();
                String menuBackground = "/Users/Felix/IdeaProjects/RobotTurtle2/imagesTurtle/Menu.jpg";
                JLabel menuPic = new JLabel(menuBackground);
                JButton bouton1 = new JButton("player 1");
                JButton bouton2 = new JButton("player 2");
                JButton bouton3 = new JButton("player 3");
                JButton bouton4 = new JButton("player 4");
                //pan.setContentPane(new Panneau(menuBackground));
                mp.revalidate();
                mp.repaint();
                mp.setVisible(true);
                System.out.println("Test");
                 */

                Game game = new Game();
                game.initialisationJeu();
                game.Jouer();


            }
        });

    }
    /*
    public static void main(String[] args) {

        Menu menuboutons = new Menu();
    }

     */

}
