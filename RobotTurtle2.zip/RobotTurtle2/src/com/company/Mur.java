package com.company;

public class Mur {

    boolean destructible;
    String Type;

    public Mur(boolean destructible,String Type){
        this.destructible=destructible;
        this.Type=Type;
    }
    public boolean isDestructible(){
        return this.destructible;
    }

    public String getType() {
        return this.Type;
    }
}
